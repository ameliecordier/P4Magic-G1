/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author p1501022
 */
public class DisappearColumnEffect extends Effect{
    
    /**
     * This effect clear the column.
     *
     * @param line
     * @param column
     * @param game
     */
    @Override
    public void playEffect(int line, int column, Game game) {
        int i = 1;
        while(i < game.getBoard().getHeight()){
            game.getBoard().getTileIJ(game.getBoard().getHeight() -1, column).setStatus(-1);
            i++;
        }
    }
}
